package org.corenr.goeditor_termux;



import java.util.ArrayList;

public class Lexer {
    static {
        System.loadLibrary("lex");
    }
    public static native ArrayList<LexEntry> lex(String code);
    public static native String format(String code);
}
