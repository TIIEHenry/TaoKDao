package org.corenr.goeditor_termux.language

import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.net.Uri
import android.util.Log
//import com.example.goeditor.MyAutoCompleteProvider
import io.github.rosemoe.editor.interfaces.AutoCompleteProvider
import io.github.rosemoe.editor.interfaces.CodeAnalyzer
import io.github.rosemoe.editor.interfaces.EditorLanguage
import io.github.rosemoe.editor.widget.CodeEditor
import org.corenr.goeditor_termux.Lexer
import org.corenr.goeditor_termux.MyAutoCompleteProvider
import org.eclipse.lsp4j.*
import org.eclipse.lsp4j.jsonrpc.Launcher
import org.eclipse.lsp4j.launch.LSPLauncher
import org.eclipse.lsp4j.services.LanguageClient
import org.eclipse.lsp4j.services.LanguageServer
import java.io.File
import java.net.Socket
import java.util.concurrent.CompletableFuture

class GoLanguage
    (private val code: CodeEditor) : EditorLanguage {

    internal class Client : LanguageClient {
        override fun telemetryEvent(o: Any) {}
        override fun publishDiagnostics(publishDiagnosticsParams: PublishDiagnosticsParams) {
            Log.d("lsp4j", publishDiagnosticsParams.toString())
        }
        override fun showMessage(messageParams: MessageParams) {
            Log.d("lsp4j", messageParams.toString())
        }

        override fun showMessageRequest(showMessageRequestParams: ShowMessageRequestParams): CompletableFuture<MessageActionItem>? {
            return null
        }

        override fun logMessage(messageParams: MessageParams) {
            Log.d("lsp4j", messageParams.toString())
        }

        override fun semanticHighlighting(params: SemanticHighlightingParams?) {
            super.semanticHighlighting(params)
        }
    }
    private var socket: Socket
    private var lspLauncher: Launcher<LanguageServer>
    init {
      socket=Socket("127.0.0.1",8866)
        lspLauncher=LSPLauncher.createClientLauncher(Client(),socket.inputStream,socket.outputStream)
        lspLauncher.startListening()
        val params = InitializeParams()
        //params.workspaceFolders = list
        params.processId = 11
        params.rootUri = Uri.fromFile(file!!.parentFile).toString()
        val f = lspLauncher.remoteEndpoint.request("initialize", params).get()
        Log.d("lsp4j",if(f==null) "" else f.toString())
        val initialized=InitializedParams()
        val intitia=lspLauncher.remoteEndpoint.request("initialized", initialized).get()
        Log.d("lsp4j",if (intitia==null)"" else intitia.toString())
    }
    fun setFile(f: File) {
        if (f.exists()) file = f
    }

    override fun getAnalyzer(): CodeAnalyzer {
        return GoAnalyzer()
    }

    fun openFile(file: File){
        version=0
        setFile(file)
        val open= DidOpenTextDocumentParams()
        open.textDocument= TextDocumentItem(Uri.fromFile(file).toString(),"go",0,"")
        lspLauncher.remoteEndpoint.notify("textDocument/didOpen",open)

    }
    fun closeFile(file: File){
        val open= DidCloseTextDocumentParams()
        open.textDocument= TextDocumentIdentifier(Uri.fromFile(file).toString())
        lspLauncher.remoteEndpoint.notify("textDocument/didClose",open)
    }
    override fun getAutoCompleteProvider(): AutoCompleteProvider {
        return MyAutoCompleteProvider(code,lspLauncher)
    }

    override fun isAutoCompleteChar(c: Char): Boolean {
        return Character.isJavaIdentifierPart(c) || c == '.' || c == ':'
    }

    override fun getIndentAdvance(s: String): Int {
        return 0
    }

    override fun useTab(): Boolean {
        return false
    }

    override fun format(charSequence: CharSequence): CharSequence {
        val s = Lexer.format(charSequence.toString())
        //Log.d(this.getClass().getName(), "format: "+s);
        return s ?: charSequence
    }

    companion object {
        //private final Dirs mdirs;
        var file: File? = null
        var version:Int=0
    }

}