package org.corenr.goeditor_termux.language;

import org.corenr.goeditor_termux.LexEntry;
import org.corenr.goeditor_termux.Lexer;
import org.corenr.goeditor_termux.Token;

import java.util.ArrayList;
import java.util.Stack;

import io.github.rosemoe.editor.interfaces.CodeAnalyzer;
import io.github.rosemoe.editor.struct.BlockLine;
import io.github.rosemoe.editor.text.TextAnalyzeResult;
import io.github.rosemoe.editor.text.TextAnalyzer;
import io.github.rosemoe.editor.widget.EditorColorScheme;


public class GoAnalyzer implements CodeAnalyzer {
    @Override
    public void analyze(CharSequence content, TextAnalyzeResult colors, TextAnalyzer.AnalyzeThread.Delegate delegate) {
        StringBuilder text = content instanceof StringBuilder ? (StringBuilder) content : new StringBuilder(content);
        String code=text.toString();
        int line = 0, column = 0;
        int maxSwitch = 1, currSwitch = 0;
        Stack<BlockLine> stack = new Stack<>();
        ArrayList<LexEntry> entries= Lexer.lex(code);
        boolean first=true;
        for (int i = 0; i < entries.size(); i++) {
            LexEntry entry=entries.get(i);
            line=entry.line-1;
            column=entry.column-1;
            //Log.d("out Token",entry.toString());
            switch (entry.token){
                case SEMICOLON:
                {
                    if (first)colors.addNormalIfNull();
                    break;
                }
                case IDENT:{
                    if (i+1<entries.size() && entries.get(i+1).token== Token.LPAREN){
                        colors.addIfNeeded(line,column, EditorColorScheme.FUNCTION_NAME);
                    }
                    if (i+1<entries.size() && entries.get(i+1).token== Token.DEFINE){
                        colors.addIfNeeded(line,column, EditorColorScheme.IDENTIFIER_VAR);
                    }
                    if (((0<=i-1)&&i-1<entries.size() )&& entries.get(i-1).token== Token.VAR){
                        colors.addIfNeeded(line,column, EditorColorScheme.IDENTIFIER_VAR);
                    }
                    if (((0<=i-1)&&i-1<entries.size() )&& entries.get(i-1).token== Token.TYPE){
                        colors.addIfNeeded(line,column, EditorColorScheme.IDENTIFIER_NAME);
                    }

                    //colors.addIfNeeded(line,column,EditorColorScheme.IDENTIFIER_NAME);
                    break;
                }
                case LBRACE:{
                    colors.addIfNeeded(line, column, EditorColorScheme.OPERATOR);
                    if (stack.isEmpty()) {
                        if (currSwitch > maxSwitch) {
                            maxSwitch = currSwitch;
                        }
                        currSwitch = 0;
                    }
                    currSwitch++;
                    BlockLine block = colors.obtainNewBlock();
                    block.startLine = line;
                    block.startColumn = column;
                    stack.push(block);
                    break;
                }
                case RBRACE:{
                    colors.addIfNeeded(line, column, EditorColorScheme.OPERATOR);
                    if (!stack.isEmpty()) {
                        BlockLine block = stack.pop();
                        block.endLine = line;
                        block.endColumn = column;
                        if (block.startLine != block.endLine) {
                            colors.addBlockLine(block);
                        }
                    }
                    break;
                }
                case COMMENT:
                    colors.addIfNeeded(line, column, EditorColorScheme.COMMENT);
                    break;
                default:
                    if (entry.token.ordinal()>Token.literal_beg.ordinal()&&entry.token.ordinal()<Token.literal_end.ordinal()){
                        colors.addIfNeeded(line,column,EditorColorScheme.LITERAL);
                    }
                    if (entry.token.ordinal()>Token.keyword_beg.ordinal()&&entry.token.ordinal()<Token.keyword_end.ordinal()){
                        colors.addIfNeeded(line,column,EditorColorScheme.KEYWORD);
                    }
                    if (entry.token.ordinal()>Token.operator_beg.ordinal()&&entry.token.ordinal()< Token.operator_end.ordinal()){
                        colors.addIfNeeded(line,column,EditorColorScheme.OPERATOR);
                    }


            }
            first=false;
        }
        if (stack.isEmpty()) {
            if (currSwitch > maxSwitch) {
                maxSwitch = currSwitch;
            }
        }
        colors.determine(line);
        colors.setSuppressSwitch(maxSwitch + 10);
        colors.mExtra=column;
        //IdentifierAutoComplete.Identifiers identifiers = new IdentifierAutoComplete.Identifiers();

    }
}
