package org.corenr.goeditor_termux.language

import android.net.Uri
import io.github.rosemoe.editor.interfaces.CodeAnalyzer
import io.github.rosemoe.editor.text.TextAnalyzeResult
import io.github.rosemoe.editor.text.TextAnalyzer
import io.github.rosemoe.editor.widget.CodeEditor
import org.eclipse.lsp4j.*
import org.eclipse.lsp4j.jsonrpc.Launcher
import org.eclipse.lsp4j.services.LanguageServer

class LSPAnalyzer(launcher: Launcher<LanguageServer>):CodeAnalyzer {
    private var launcher=launcher
    override fun analyze(
        content: CharSequence?,
        colors: TextAnalyzeResult?,
        delegate: TextAnalyzer.AnalyzeThread.Delegate?
    ) {
        val uri= Uri.fromFile(GoLanguage.file!!).toString()
        val TextDocumentParams = DidChangeTextDocumentParams()
        TextDocumentParams.textDocument = VersionedTextDocumentIdentifier(uri,GoLanguage.version++)
        TextDocumentParams.contentChanges= listOf(TextDocumentContentChangeEvent(content.toString()))
        launcher.remoteEndpoint.notify("textDocument/didChange",TextDocumentParams)
        val highlightParams=DocumentHighlightParams()
        highlightParams.textDocument= TextDocumentIdentifier(uri)
     val highlight=  launcher.remoteEndpoint.request("textDocument/documentHighlight",highlightParams).get()
        println(highlight)
    }
}