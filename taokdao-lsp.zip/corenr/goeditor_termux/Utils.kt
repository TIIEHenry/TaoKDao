package org.corenr.goeditor_termux

import com.github.gzuliyujiang.chardet.CJKCharsetDetector
import io.reactivex.rxjava3.core.Completable
import io.reactivex.rxjava3.core.Single
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.nio.charset.Charset

fun loadFile(filePath:String): Single<String> {
    return Single.create { emitter ->
        val file = File(filePath)
        if (file.exists()) {
            val charset = file.inputStream().use(CJKCharsetDetector::detect)
            try {
                val text = charset?.let { file.readText(charset = it) }
                emitter.onSuccess(text)
            } catch (e: OutOfMemoryError) {
                emitter.onError(OutOfMemoryError(filePath))
            }
        } else {
            emitter.onError(FileNotFoundException(filePath))
        }
    }
}
fun saveFile(filePath: String, text: String, charset:Charset): Completable {
    return Completable.create { emitter ->
        try {
            val file = File(filePath)
            if (!file.exists()) {
                val parentFile = file.parentFile!!
                if (!parentFile.exists()) {
                    parentFile.mkdirs()
                }
                file.createNewFile()
            }
            file.writeText(text, charset)

            emitter.onComplete()
        } catch (e: IOException) {
            emitter.onError(e)
        }
    }
}