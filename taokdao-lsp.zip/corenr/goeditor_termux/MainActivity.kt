package org.corenr.goeditor_termux

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.StrictMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import me.rosuh.filepicker.adapter.FileListAdapter
import me.rosuh.filepicker.config.FileItemOnClickListener
import me.rosuh.filepicker.config.FilePickerManager
import me.rosuh.filepicker.filetype.FileType
import org.corenr.goeditor_termux.databinding.ActivityMainBinding
import org.corenr.goeditor_termux.language.GoLanguage
import java.io.File
import java.io.IOException
import java.util.*


class MainActivity : AppCompatActivity() {
    private var mTimer: Timer? = null
    private var extracted: Boolean = true
private var language:GoLanguage?=null
    //private var docPaths: ArrayList<Uri> = ArrayList()
    private var binding: ActivityMainBinding? = null
    private var path: File? = null
    val REQ_CODE=23333
    var GO = "Go"
    var SETTINGS = "GoSettings"
    //var mDirs: Dirs? = null
    private fun writef() {
        saveFile(path!!.absolutePath, binding!!.code.text.toString(), Charsets.UTF_8).doOnComplete {
            // toast("save success:" + path!!)
        }.doOnError {
            toast(it.localizedMessage.orEmpty())
        }.subscribe()
    }

    private fun toast(str: String) {
        Toast.makeText(this, str, Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        init()
    }

    fun init() {
        StrictMode.setThreadPolicy(
            StrictMode.ThreadPolicy.Builder().penaltyLog().build()
        )
        binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding!!.root)
        if (ContextCompat.checkSelfPermission(this, "com.termux.permission.RUN_COMMAND") != PackageManager.PERMISSION_GRANTED) {
            extracted=false
            ActivityCompat.requestPermissions(this, arrayOf("com.termux.permission.RUN_COMMAND"),REQ_CODE );
        }
            setSupportActionBar(binding!!.toolbar2)
            path = File(filesDir,"tmp.go")
            path?.createNewFile()
            val savePath=getSharedPreferences(SETTINGS,Context.MODE_PRIVATE).getString("path","")
            if (!savePath.isNullOrEmpty())
                path=File(savePath)
            if (path!!.exists())
                loadFile(path!!.absolutePath).doOnSuccess {
                    binding!!.code.setText(it)
                }.doOnError {
                    binding!!.code.visibility = View.INVISIBLE
                }.subscribe()
            GoLanguage.file= path
        newLanguage()
        language?.openFile(path!!)
            binding!!.code.setEditorLanguage(language)
     }
fun newLanguage(){
    try {
        language = GoLanguage(binding!!.code)
    }catch (e:java.net.ConnectException){
        toast("请先配置termux的gopls并关闭电池优化\n配置参数\n -listen 127.0.0.1:8866")
        Thread.sleep(1000)
        finish()
    }
}
    override fun onStart() {
        super.onStart()
        mTimer = Timer()
        mTimer?.schedule(object : TimerTask() {
            override fun run() {
                writef()
            }

        },
                2600
        )
    }

    override fun onStop() {
        super.onStop()
        mTimer?.cancel()
        writef()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_act, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.code_format -> binding!!.code.formatCodeAsync()
            R.id.code_redo -> binding!!.code.redo()
            R.id.code_undo -> binding!!.code.undo()
            R.id.open_file -> {
                FilePickerManager.from(this)

                        //.storageType(storageMediaType = FilePickerConfig.STORAGE_CUSTOM_ROOT_PATH)
                        //.enableSingleChoice()
                        .setItemClickListener(object : FileItemOnClickListener {
                            override fun onItemChildClick(itemAdapter: FileListAdapter, itemView: View, position: Int) {

                            }

                            override fun onItemClick(itemAdapter: FileListAdapter, itemView: View, position: Int) {
                            }

                            override fun onItemLongClick(itemAdapter: FileListAdapter, itemView: View, position: Int) {
                                AlertDialog.Builder(itemView.context)
                                        .setSingleChoiceItems(arrayOf("创建", "删除"), -1) { dialog, which ->
                                                if (which >= 0) {
                                                        when (which) {
                                                            1 -> {

                                                                deleteFileDialog(itemView.context,itemAdapter.getItem(position)?.filePath!!)
                                                            }
                                                            0 -> {
                                                                createFileDialog(itemView.context,itemAdapter.getItem(position)?.filePath!!)
                                                            }
                                                        }
                                                }
                                            dialog.dismiss()
                                        }.show()

                            }

                        })
                        .registerFileType(listOf(object : FileType {
                            override val fileIconResId: Int
                                get() = R.mipmap.go
                            override val fileType: String
                                get() = "go"

                            override fun verify(fileName: String): Boolean {
                                return fileName.endsWith(".go")
                            }
                        }))

                        .maxSelectable(1)
                        .forResult(FilePickerManager.REQUEST_CODE)
            }
            R.id.save_file -> writef()
            R.id.new_file -> {
                val edit = EditText(this)
                AlertDialog.Builder(this)
                        .setView(edit)
                        .setPositiveButton("确认") { dialogInterface: DialogInterface, i: Int ->
                            try {
                                File(path!!.parentFile, edit.text.toString()).createNewFile()
                            } catch (e: IOException) {
                                e.printStackTrace()
                                toast(e.localizedMessage.orEmpty())
                            }
                        }.setNegativeButton("取消") { dialogInterface: DialogInterface, i: Int -> }
                        .show()
            }
            R.id.gorun -> {
                if (extracted) {
                    intent = Intent();
                    intent.setClassName("com.termux", "com.termux.app.RunCommandService");
                    intent.setAction("com.termux.RUN_COMMAND");
                    intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
                    intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", "go run . ;read"));
                    intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", path!!.parent);
                    intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false);
                    startService(intent)
                }else{
                    toast("没有termux权限")
                }
            }
            R.id.open_terminal->{
if(extracted){
                intent =  Intent();
                intent.setClassName("com.termux", "com.termux.app.RunCommandService");
                intent.setAction("com.termux.RUN_COMMAND");
                intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
                intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", path!!.parent);
                intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false);
                startService(intent)
            }else{
            toast("没有termux权限")
        }
            }
        }
        return super.onOptionsItemSelected(item)
    }
    companion object {
        fun createFileDialog(ctx:Context,path: String) {
            val edit=EditText(ctx)
            edit.setTextColor(Color.BLACK)
           val dialog= AlertDialog.Builder(ctx)
                    .setView(edit)
                    .setPositiveButton("文件夹") { d, w -> File(File(path).parentFile, edit.text.toString()).mkdir();d.dismiss() }
                    .setNegativeButton("文件") { d, _ -> File(File(path).parentFile, edit.text.toString()).createNewFile();d.dismiss() }
                    .show()
                    dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLACK)
            dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.BLACK)

        }

        fun deleteFileDialog(ctx: Context,path: String) {
           val dialog=AlertDialog.Builder(ctx)
                    .setPositiveButton("确定") { d, w -> File(path).deleteRecursively();d.dismiss() }
                    .setNegativeButton("取消") { d, _ -> d.dismiss() }
                    .show()

            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLACK)
            dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.BLACK)
            }
    }
private fun savePath(file: String){
    this.getSharedPreferences(SETTINGS,Context.MODE_PRIVATE).edit().putString("path",file).commit()
}



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_CODE->{
                extracted=true
            }
            FilePickerManager.REQUEST_CODE -> {
                val docPaths = FilePickerManager.obtainData()
                if (docPaths.isNotEmpty()) {

                    language?.closeFile(path!!)
                    path = File(docPaths[0])
                    loadFile(path!!.absolutePath).doOnSuccess { binding!!.code.setText(it);savePath(path!!.absolutePath)}
                            .doOnError { toast(it.localizedMessage.orEmpty()) }
                            .subscribe()
                   // binding!!.code.setEditorLanguage(GoLanguage(binding!!.code, mDirs, File(path)))
                    language?.openFile(path!!)
                }
            }
        }
    }

}