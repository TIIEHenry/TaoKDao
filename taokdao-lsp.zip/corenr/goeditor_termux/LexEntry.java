package org.corenr.goeditor_termux;

import androidx.annotation.NonNull;

public class LexEntry {
public final       int line;
public final int column;
public final Token token;
public final String literal;
public LexEntry(int l,int c,int t,String str){
line=l;
column=c;
token= Token.fromInt(t);
literal=str;
}

    @NonNull
    @Override
    public String toString() {
        return line+":"+column+";"+token+";"+literal;
    }
}
