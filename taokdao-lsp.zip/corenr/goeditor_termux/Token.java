package org.corenr.goeditor_termux;

public enum Token {
    // Special tokens
    ILLEGAL ,
            EOF,
    COMMENT,

            literal_beg,
    // Identifiers and basic type literals
    // (these tokens stand for classes of literals)
    IDENT,  // main
            INT ,   // 12345
    FLOAT , // 123.45
            IMAG,   // 123.45i
    CHAR  , // 'a'
            STRING, // "abc"
    literal_end,

            operator_beg,
    // Operators and delimiters
    ADD, // +
            SUB, // -
    MUL, // *
            QUO, // /
    REM ,// %

            AND,     // &
    OR  ,    // |
            XOR,     // ^
    SHL ,    // <<
            SHR ,    // >>
    AND_NOT, // &^

            ADD_ASSIGN, // +=
    SUB_ASSIGN, // -=
            MUL_ASSIGN ,// *=
    QUO_ASSIGN ,// /=
            REM_ASSIGN, // %=

    AND_ASSIGN   ,  // &=
            OR_ASSIGN  ,    // |=
    XOR_ASSIGN   ,  // ^=
            SHL_ASSIGN,     // <<=
    SHR_ASSIGN  ,   // >>=
            AND_NOT_ASSIGN, // &^=

    LAND,  // &&
            LOR ,  // ||
    ARROW, // <-
            INC ,  // ++
    DEC,   // --

            EQL,    // ==
    LSS ,   // <
            GTR,    // >
    ASSIGN, // =
            NOT ,   // !

    NEQ    ,  // !=
            LEQ,      // <=
    GEQ ,     // >=
            DEFINE ,  // :=
    ELLIPSIS, // ...

            LPAREN, // (
    LBRACK, // [
            LBRACE ,// {
    COMMA , // ,
            PERIOD, // .

    RPAREN  ,  // )
            RBRACK,    // ]
    RBRACE ,   // }
            SEMICOLON, // ;
    COLON  ,   // :
            operator_end,

    keyword_beg,
            // Keywords
            BREAK,
    CASE,
            CHAN,
    CONST,
            CONTINUE,

    DEFAULT,
            DEFER,
    ELSE,
            FALLTHROUGH,
    FOR,

            FUNC,
    GO,
            GOTO,
    IF,
            IMPORT,

    INTERFACE,
            MAP,
    PACKAGE,
            RANGE,
    RETURN,

            SELECT,
    STRUCT,
            SWITCH,
    TYPE,
            VAR,
    keyword_end;
    private int id;
    private Token(int i){
        id=i;
    }

    private Token() {
    }
    public boolean Compare(int i){return ordinal() == i;}
    public static Token fromInt(int _id){
        Token[] Ts = Token.values();
        for(int i = 0; i < Ts.length; i++)
        {
            if(Ts[i].Compare(_id))
                return Ts[i];
        }
        return EOF;
    }
}

