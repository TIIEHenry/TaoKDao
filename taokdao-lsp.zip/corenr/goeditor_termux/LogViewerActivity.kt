package org.corenr.goeditor_termux

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import org.corenr.goeditor_termux.databinding.LogBinding

class LogViewerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       val binding = LogBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val log_summary = intent.getStringExtra("log_summary")
        if (!log_summary.isNullOrEmpty()) {
            binding.textLog.text= log_summary
        }
    }
}