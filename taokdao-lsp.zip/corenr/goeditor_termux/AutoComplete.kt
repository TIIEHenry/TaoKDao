package org.corenr.goeditor_termux

import android.net.Uri
import android.util.Log
import io.github.rosemoe.editor.interfaces.AutoCompleteProvider
import io.github.rosemoe.editor.struct.ResultItem
import io.github.rosemoe.editor.text.TextAnalyzeResult
import io.github.rosemoe.editor.widget.CodeEditor
import org.corenr.goeditor_termux.language.GoLanguage
import org.eclipse.lsp4j.*
import org.eclipse.lsp4j.jsonrpc.Launcher
import org.eclipse.lsp4j.jsonrpc.messages.Either
import org.eclipse.lsp4j.launch.LSPLauncher
import org.eclipse.lsp4j.services.LanguageClient
import org.eclipse.lsp4j.services.LanguageServer
import java.io.*
import java.net.URI
import java.util.*
import java.util.concurrent.CompletableFuture


internal class Client : LanguageClient {
    override fun telemetryEvent(o: Any) {}
    override fun publishDiagnostics(publishDiagnosticsParams: PublishDiagnosticsParams) {
        Log.d("lsp4j", publishDiagnosticsParams.toString())
    }
    override fun showMessage(messageParams: MessageParams) {
        Log.d("lsp4j", messageParams.toString())
    }

    override fun showMessageRequest(showMessageRequestParams: ShowMessageRequestParams): CompletableFuture<MessageActionItem>? {
        return null
    }

    override fun logMessage(messageParams: MessageParams) {
        Log.d("lsp4j", messageParams.toString())
    }

}

class AutoComplete(editor: CodeEditor,lspLauncher: Launcher<LanguageServer>)  {
    private var editor: CodeEditor = editor
    private var ser=lspLauncher

    fun getCompletionList(file: File): ArrayList<ResultItem> {
        val uri=Uri.fromFile(file).toString()
        val t = TextDocumentIdentifier()
        t.uri = uri
        val params1 = CompletionParams()
        val position = Position(editor.cursor.leftLine,editor.cursor.leftColumn-1)
        params1.textDocument = t
        params1.position = position

        val TextDocumentParams = DidChangeTextDocumentParams()
        TextDocumentParams.textDocument =VersionedTextDocumentIdentifier(uri,GoLanguage.version++)
        TextDocumentParams.contentChanges= listOf(TextDocumentContentChangeEvent(editor.text.toString()))
       ser.remoteEndpoint.notify("textDocument/didChange",TextDocumentParams)

        val f1: CompletableFuture<*> = ser.remoteEndpoint.request("textDocument/completion", params1)
        val either = f1.get() as Either<*, CompletionList>
        val list = ArrayList<ResultItem>()
        val items=either.right.items;
        items.sortBy{ it.sortText.toInt() }
        if (either.isRight) {
            for (item in items) {
                val str=(if(item.filterText==null) item.label else item.filterText.toString());
                list.add(ResultItem(str,item.kind.toString()))
            }
        } else {
            return list
        }
        return list
    }

}


class MyAutoCompleteProvider(editor: CodeEditor, lspLauncher: Launcher<LanguageServer>) : AutoCompleteProvider {
    private var code_editor: CodeEditor? = null
    private var lspLauncher=lspLauncher
    companion object  {
     var instance:AutoComplete?=null
      }
    init {

        code_editor = editor
    }

    override fun getAutoCompleteItems(prefix: String?, isInCodeBlock: Boolean, colors: TextAnalyzeResult?, line: Int): MutableList<ResultItem> {
        if (instance==null)
    instance=AutoComplete(this.code_editor!!,lspLauncher = lspLauncher)
return instance!!.getCompletionList(GoLanguage.file!!)
    }

}