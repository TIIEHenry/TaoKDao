package org.corenr.goeditor_termux

import android.app.Application

class MyApplication:Application() {
    override fun onCreate() {
        super.onCreate()
        CrashHandler.getInstance(this)
    }
}